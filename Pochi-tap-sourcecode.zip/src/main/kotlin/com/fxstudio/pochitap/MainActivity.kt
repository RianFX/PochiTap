package com.fxstudio.pochitap

import android.os.Bundle
import android.media.AudioAttributes
import android.media.SoundPool
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import android.content.Context
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.animation.core.tween
import androidx.compose.ui.draw.alpha
import kotlin.random.Random
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        setContent {
            PochiTapApp()
        }
    }
}

@Composable
fun PochiTapApp() {

        val context = LocalContext.current
    val prefs = remember {
        context.getSharedPreferences("pochitap", Context.MODE_PRIVATE)
    }

    var score by remember { mutableIntStateOf(0) }
    var highScore by remember { mutableIntStateOf(prefs.getInt("high_score", 0)) }
    var soundLoaded by remember { mutableStateOf(false) }
val haptic = LocalHapticFeedback.current
var hapticOn by remember { mutableStateOf(prefs.getBoolean("haptic_on", true)) }
var soundOn by remember { mutableStateOf(prefs.getBoolean("sound_on", true)) }
var plusOnes by remember { mutableStateOf(listOf<PlusOne>()) }
var plusOneId by remember { mutableIntStateOf(0) }
var showResetDialog by remember { mutableStateOf(false) }
var tapPower by remember { mutableIntStateOf(prefs.getInt("tap_power", 1)) }
val upgradeCost = tapPower * tapPower * 150
var combo by remember { mutableIntStateOf(0) }
var lastTapTime by remember { mutableLongStateOf(0L) }
val comboMultiplier = 1 + (combo / 10).coerceAtMost(4)

LaunchedEffect(lastTapTime) {
    delay(800)
    combo = 0
}
val vibrator = remember {
    context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
}
    val characterScale = remember {
        Animatable(1f)
    }

    val scope = rememberCoroutineScope()
    val audioAttributes = remember {
        AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_GAME)
        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
        .build()
    }

    val soundPool = remember {
        SoundPool.Builder()
        .setMaxStreams(5)
        .setAudioAttributes(audioAttributes)
        .build()
    }


var soundId by remember { mutableIntStateOf(0) }

DisposableEffect(soundPool) {
    soundPool.setOnLoadCompleteListener { _, _, status ->
        if (status == 0) soundLoaded = true
    }
    soundId = soundPool.load(context, R.raw.nyaa, 1)

    onDispose {
        soundPool.release()
    }
}

    val backgroundColor = Color(0xFFEAF7F5)
    val accentColor = Color(0xFF63B8AD)

    Column(
        modifier = Modifier
        .fillMaxSize()
        .background(backgroundColor)
        .safeDrawingPadding()
        .padding(20.dp),

        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {

        // HEADER
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "PochiTap",
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF315D62)
            )

            Text(
                text = "Just One More Tap!",
                fontSize = 14.sp,
                color = Color.Gray
            )
        }

        // SCORE
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "YOUR SCORE",
                fontSize = 13.sp,
                color = Color.Gray
            )

            Text(
                text = "%,d".format(java.util.Locale.getDefault(), score),
                fontSize = 42.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF315D62)
            )
            Text(
    text = "BEST: " + "%,d".format(java.util.Locale.getDefault(), highScore),
    fontSize = 14.sp,
    color = Color.Gray
)
if (combo >= 10) {
    Text(
        text = "COMBO x$comboMultiplier",
        fontSize = 16.sp,
        fontWeight = FontWeight.ExtraBold,
        color = Color(0xFFFF6F91)
    )
}
        }

        // CHARACTER
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(
                    id = if (characterScale.value < 0.98f)
                        R.drawable.character_pop
                    else
                        R.drawable.character_idle
                ),
                contentDescription = "PochiTap Character",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .scale(characterScale.value)
                    .clickable(
                        indication = null,
                        interactionSource = remember {
                            MutableInteractionSource()
                        }
                    ) {
                        val now = System.currentTimeMillis()
combo = if (now - lastTapTime < 600) combo + 1 else 1
lastTapTime = now

val gain = tapPower * (1 + (combo / 10).coerceAtMost(4))
score += gain

plusOneId++
plusOnes = plusOnes + PlusOne(plusOneId, Random.nextInt(-60, 60), gain)
                        if (score > highScore) {
                            highScore = score
                            prefs.edit().putInt("high_score", highScore).apply()
                        }

                        if (hapticOn) {
                            try {
                                vibrator.vibrate(
                                    VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE)
                                )
                            } catch (e: Exception) {
                            }
                        }

                        if (soundLoaded && soundOn) {
                            soundPool.play(
                                soundId,
                                1f,
                                1f,
                                1,
                                0,
                                1f
                            )
                        }

                        scope.launch {
                            characterScale.snapTo(0.92f)

                            characterScale.animateTo(
                                targetValue = 1f,
                                animationSpec = spring(
                                    dampingRatio = 0.55f,
                                    stiffness = 180f
                                )
                            )
                        }
                    }
            )

                        plusOnes.forEach { item ->
                key(item.id) {
                    FloatingPlusOne(x = item.x, amount = item.amount) {
                        plusOnes = plusOnes.filter { it.id != item.id }
                    }
                }
            }
        }

        // FOOTER
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Surface(
                color = accentColor,
                shape = RoundedCornerShape(20.dp)
            ) {
                Text(
                    text = "TAP THE CHARACTER!",
                    modifier = Modifier.padding(
                        horizontal = 28.dp,
                        vertical = 14.dp
                    ),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }

            Spacer(
                modifier = Modifier.height(12.dp)
            )

            Text(
                text = "Keep tapping!",
                color = Color.Gray,
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

Button(
    onClick = {
        score -= upgradeCost
        tapPower++
        prefs.edit().putInt("tap_power", tapPower).apply()
    },
    enabled = score >= upgradeCost
) {
  Text("Upgrade: +${tapPower + 1} per tap (cost $upgradeCost)")
}

Row(verticalAlignment = Alignment.CenterVertically) {
    Text(
        text = "Vibration",
        color = Color.Gray,
        fontSize = 13.sp
    )

    Spacer(modifier = Modifier.width(8.dp))

    Switch(
        checked = hapticOn,
        onCheckedChange = {
            hapticOn = it
            prefs.edit().putBoolean("haptic_on", it).apply()
        }
    )

    Spacer(modifier = Modifier.width(20.dp))

    Text(
        text = "Sound",
        color = Color.Gray,
        fontSize = 13.sp
    )

    Spacer(modifier = Modifier.width(8.dp))

    Switch(
        checked = soundOn,
        onCheckedChange = {
            soundOn = it
            prefs.edit().putBoolean("sound_on", it).apply()
        }
    )
}
Row(verticalAlignment = Alignment.CenterVertically) {
    TextButton(
        onClick = { score = 0 },
        contentPadding = PaddingValues(horizontal = 8.dp)
    ) {
        Text(
            text = "Reset score",
            color = Color.Gray,
            fontSize = 12.sp
        )
    }

    TextButton(
        onClick = { showResetDialog = true },
        contentPadding = PaddingValues(horizontal = 8.dp)
    ) {
        Text(
            text = "Reset best",
            color = Color.Gray,
            fontSize = 12.sp
        )
    }

    TextButton(
        onClick = {
            tapPower = 1
            prefs.edit().putInt("tap_power", 1).apply()
        },
        contentPadding = PaddingValues(horizontal = 8.dp)
    ) {
        Text(
            text = "Reset upgrade",
            color = Color.Gray,
            fontSize = 12.sp
        )
    }
}
if (showResetDialog) {
    AlertDialog(
        onDismissRequest = { showResetDialog = false },
        title = { Text("Reset high score?") },
        text = { Text("Your saved high score will be deleted and can't be restored.") },
        confirmButton = {
            TextButton(
                onClick = {
                    highScore = 0
                    prefs.edit().putInt("high_score", 0).apply()
                    showResetDialog = false
                }
            ) {
                Text("Yes, Reset")
            }
        },
        dismissButton = {
            TextButton(onClick = { showResetDialog = false }) {
                Text("Cancel")
            }
        }
    )
}
        }
    }
}
data class PlusOne(val id: Int, val x: Int, val amount: Int)

@Composable
fun FloatingPlusOne(x: Int, amount: Int, onFinished: () -> Unit) {
    val progress = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        progress.animateTo(1f, tween(700))
        onFinished()
    }

    Text(
        text = "+$amount",
        fontSize = 30.sp,
        fontWeight = FontWeight.ExtraBold,
        color = Color.Black,
        modifier = Modifier
            .offset(x = x.dp, y = (-110 * progress.value).dp)
            .alpha(1f - progress.value)
    )
}